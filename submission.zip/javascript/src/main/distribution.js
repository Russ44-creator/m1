module.exports = {
  util: require('./distribution/util/serialization.js'),
};
